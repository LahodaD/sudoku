﻿namespace Sudoku
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.manualEntry = new System.Windows.Forms.Button();
            this.saveManualEntry = new System.Windows.Forms.Button();
            this.solveBtn = new System.Windows.Forms.Button();
            this.saveGameBtn = new System.Windows.Forms.Button();
            this.loadSaveGameBtn = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel1.Location = new System.Drawing.Point(30, 27);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(481, 445);
            this.panel1.TabIndex = 0;
            // 
            // manualEntry
            // 
            this.manualEntry.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.manualEntry.Location = new System.Drawing.Point(605, 72);
            this.manualEntry.Name = "manualEntry";
            this.manualEntry.Size = new System.Drawing.Size(128, 44);
            this.manualEntry.TabIndex = 1;
            this.manualEntry.Text = "Ruční zadání";
            this.manualEntry.UseVisualStyleBackColor = false;
            this.manualEntry.Click += new System.EventHandler(this.manualEntry_Click);
            // 
            // saveManualEntry
            // 
            this.saveManualEntry.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.saveManualEntry.Location = new System.Drawing.Point(605, 251);
            this.saveManualEntry.Name = "saveManualEntry";
            this.saveManualEntry.Size = new System.Drawing.Size(128, 51);
            this.saveManualEntry.TabIndex = 2;
            this.saveManualEntry.Text = "ukončit ruční zadávání";
            this.saveManualEntry.UseVisualStyleBackColor = false;
            this.saveManualEntry.Click += new System.EventHandler(this.saveManualEntry_Click);
            // 
            // solveBtn
            // 
            this.solveBtn.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.solveBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.solveBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.solveBtn.Location = new System.Drawing.Point(593, 412);
            this.solveBtn.Name = "solveBtn";
            this.solveBtn.Size = new System.Drawing.Size(154, 60);
            this.solveBtn.TabIndex = 3;
            this.solveBtn.Text = "VYŘEŠIT";
            this.solveBtn.UseVisualStyleBackColor = false;
            this.solveBtn.Click += new System.EventHandler(this.solveBtn_Click);
            // 
            // saveGameBtn
            // 
            this.saveGameBtn.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.saveGameBtn.Location = new System.Drawing.Point(605, 308);
            this.saveGameBtn.Name = "saveGameBtn";
            this.saveGameBtn.Size = new System.Drawing.Size(128, 51);
            this.saveGameBtn.TabIndex = 4;
            this.saveGameBtn.Text = "Uložit hru";
            this.saveGameBtn.UseVisualStyleBackColor = false;
            this.saveGameBtn.Click += new System.EventHandler(this.saveGameBtn_Click);
            // 
            // loadSaveGameBtn
            // 
            this.loadSaveGameBtn.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.loadSaveGameBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.loadSaveGameBtn.Location = new System.Drawing.Point(605, 122);
            this.loadSaveGameBtn.Name = "loadSaveGameBtn";
            this.loadSaveGameBtn.Size = new System.Drawing.Size(128, 53);
            this.loadSaveGameBtn.TabIndex = 5;
            this.loadSaveGameBtn.Text = "Načíst uloženou hru";
            this.loadSaveGameBtn.UseVisualStyleBackColor = false;
            this.loadSaveGameBtn.Click += new System.EventHandler(this.loadSaveGameBtn_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.Location = new System.Drawing.Point(607, 27);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(102, 25);
            this.label2.TabIndex = 7;
            this.label2.Text = "Nová Hra";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label3.Location = new System.Drawing.Point(607, 207);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(99, 25);
            this.label3.TabIndex = 8;
            this.label3.Text = "Možnosti";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(803, 521);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.loadSaveGameBtn);
            this.Controls.Add(this.saveGameBtn);
            this.Controls.Add(this.solveBtn);
            this.Controls.Add(this.saveManualEntry);
            this.Controls.Add(this.manualEntry);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button manualEntry;
        private System.Windows.Forms.Button saveManualEntry;
        private System.Windows.Forms.Button solveBtn;
        private System.Windows.Forms.Button saveGameBtn;
        private System.Windows.Forms.Button loadSaveGameBtn;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
    }
}

