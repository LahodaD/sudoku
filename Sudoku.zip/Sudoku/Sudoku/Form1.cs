﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sudoku
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        
        SudokuCells[,] cells = new SudokuCells[9,9];

        private void createGameFild()
        {
            for (int i = 0; i < 9; i++)
            {
                for (int j = 0; j < 9; j++)
                {
                    cells[i, j] = new SudokuCells();
                    cells[i, j].Size = new Size(40, 40);
                    cells[i, j].Location = new Point(i * 40, j * 40);
                    cells[i, j].FlatStyle = FlatStyle.Flat;
                    cells[i, j].FlatAppearance.BorderColor = Color.Black;

                    //cells[i, j].KeyPress += pressCell; //pridani delegata +=, -= odebrani delegata

                    panel1.Controls.Add(cells[i, j]);
                }
            }
        }

        private void pressCell(Object sender, KeyPressEventArgs e)
        {
            SudokuCells cell = (SudokuCells)sender;
            int cellValue;

            if (cell.IsLocked)
            {
                return;
            }

            if (int.TryParse(e.KeyChar.ToString(), out cellValue)) //osetreni pro vstup zda se jedna o cislo
            {
                if (cellValue == 0)
                {
                    cell.Clear();
                }
                else
                {
                    cell.SetText(cellValue);
                }

                cell.ForeColor = SystemColors.ControlDark;
            }

        }

        private void clearGameBoard()
        {
            for (int i = 0; i < 9; i++)
            {
                for (int j = 0; j < 9; j++)
                {
                    cells[i, j].Clear();
                    
                }
            }
        }

        private bool checkValidValue(int xCoordinate, int yCoordinate, int value)
        {
            for (int i = 0; i < 9; i++)
            {
                if (cells[xCoordinate, i].Value == value && i != yCoordinate)
                {
                    return false;
                }
                if (cells[i, yCoordinate].Value == value && i != xCoordinate)
                {
                    return false;
                }
            }

            // kontrola prislusneho cverce 3*3
            int tmpI = xCoordinate - (xCoordinate % 3);
            int tmpJ = yCoordinate - (yCoordinate % 3);

            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    if (cells[tmpI + i, tmpJ + j].Value == value && tmpI+i != xCoordinate && tmpJ+j != yCoordinate)
                    {
                        return false;
                    }
                }
            }
            return true;
        }

        private bool solve()
        {
            int row = 0;
            int col = 0;
            bool isEmpty = true;
            for (int i = 0; i < 9; i++)
            {
                for (int j = 0; j < 9; j++)
                {
                    if (cells[i, j].Value == 0)
                    {
                        row = i;
                        col = j;
                        isEmpty = false;
                        break;
                    }
                }
                if (!isEmpty)
                {
                    break;
                }
            }

            if (isEmpty)
            {
                return true;
            }

            for (int num = 1; num <= 9; num++)
            {
                if (checkValidValue(row, col, num))
                {
                    cells[row, col].SetText(num);
                    if (solve())
                    {
                        return true;
                    }
                    else
                    {
                        cells[row, col].Value = 0;
                    }
                }
            }
            return false;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            createGameFild();         
        }

        private void manualEntry_Click(object sender, EventArgs e)
        {
            clearGameBoard();
            foreach (SudokuCells cell in cells)
            {
                cell.KeyPress += pressCell;
            }
        }

        private void saveManualEntry_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 9; i++)
            {
                for (int j = 0; j < 9; j++)
                {
                    if (cells[i, j].Value != 0)
                    {
                        if (checkValidValue(i, j, cells[i, j].Value) == false)
                        {
                            clearGameBoard();
                            MessageBox.Show("Wrong input");
                            return;
                        }
                        
                    }
                }
            }

            foreach (SudokuCells cell in cells)
            {              
                if (cell.Value != 0)
                {
                    cell.IsLocked = true;
                }
            }
        }

        private void solveBtn_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 9; i++)
            {
                for (int j = 0; j < 9; j++)
                {
                    if (cells[i, j].Value != 0)
                    {
                        if (checkValidValue(i, j, cells[i, j].Value) == false)
                        {
                            clearGameBoard();
                            MessageBox.Show("Wrong input");
                            return;
                        }

                    }
                }
            }

            if (!solve())
            {
                MessageBox.Show("No solution found");
            }
            
        }

        private void saveGame()
        {
            using (StreamWriter sw = new StreamWriter(@"saveGame.txt"))
            {
                for (int i = 0; i < 9; i++)
                {
                    for (int j = 0; j < 9; j++)
                    {
                        sw.Write(cells[j, i].Value);
                    }
                    sw.WriteLine();
                }
                sw.Flush();
            }
        }

        private void saveGameBtn_Click(object sender, EventArgs e)
        {
            saveGame();
        }

        private void loadSaveGame()
        {
            string fileName = @"saveGame.txt";

            if (!File.Exists(fileName))
            {
                MessageBox.Show("The game is not saved, use manual entry");
                return;
            }

            int row = 0;
            using (StreamReader sr = new StreamReader(fileName))
            {
                clearGameBoard();

                string s;
                
                while ((s = sr.ReadLine()) != null)
                {
                    //TODO: zkontrolovat pocet radku a sloupcu
                    if (s.Length != 9)
                    {
                        MessageBox.Show("The saved game is corrupted");
                        return;
                    }

                    if (row > 9)
                    {
                        break;
                    }

                    for (int i = 0; i < 9; i++)
                    {
                        cells[i, row].Value = s[i] - '0'; //vrati to ciselnou hodnotu s[i]
                    }
                    row++;
                }
            }

            if (row != 9)
            {
                MessageBox.Show("The saved game is corrupted");
                return;
            }

            foreach (SudokuCells cell in cells)
            {
                if (cell.Value != 0)
                {
                    cell.SetText(cell.Value);
                    cell.IsLocked = true;
                    cell.ForeColor = SystemColors.ControlDark;
                    cell.KeyPress += pressCell;
                }
            }
        }

        private void loadSaveGameBtn_Click(object sender, EventArgs e)
        {
            loadSaveGame();
        }
    }
}
