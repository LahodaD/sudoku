﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sudoku
{
    class SudokuCells : Button
    {
        public bool IsLocked { get; set; }
        public int Value { get; set; }
        public void Clear()
        {
            Text = string.Empty;
            IsLocked = false;
            Value = 0;
        }

        public void SetText(int value)
        {
            Text = value.ToString();
            Value = value;
        }
    }
}
